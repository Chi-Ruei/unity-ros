# [MessageGenerationConsoleTool](https://github.com/siemens/ros-sharp/blob/master/Libraries/MessageGenerationConsoleTool) #
Console tool for generating C# source code for [ROS](http://www.ros.org/) message/service/action.

__Please see the [Wiki](https://github.com/siemens/ros-sharp/wiki) page for [New Message Types](https://github.com/siemens/ros-sharp/wiki/Dev_NewMessageTypes) for further info.__

---

© Siemens AG, 2019

Author: Sifan Ye (sifan.ye@siemens.com)
